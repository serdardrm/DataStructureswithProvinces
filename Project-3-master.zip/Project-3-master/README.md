# Project-3
Bu pojede bağllı liste ve düğüm yapısını kullanarak çift yönlü bağıl liste oluşturma, düğümlerde bilgi saklama, bu bilgileri karşılaştırma ve değiştirme işlemlerini öğrendik.
Bunların yanısıra standart C dilinde dinamik hafıza yönetimini öğrendik.
Hafıza yönetimini kullanırken malloc fonksiyonu kavradık.
Aynı zamanda text dosyası üzerinden verip alıp bunları düğümlerdeki dizilere ve değişkenlere atama işlemleri öğrenmiş olduk.
Aynı zamanda 2 bağlı listeyi kullanarak 2 boyutlu bağlı liste kullanımını da öğrendik.
